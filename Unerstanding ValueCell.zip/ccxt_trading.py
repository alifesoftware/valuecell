
Supports:
- Spot trading
- Futures/Perpetual contracts (USDT-margined, coin-margined)
- Leverage trading (cross/isolated margin)
- Multiple exchanges via CCXT unified API
"""

from __future__ import annotations

import asyncio
from typing import Dict, List, Optional

import ccxt.async_support as ccxt
from loguru import logger

from valuecell.agents.common.trading.models import (
    FeatureVector,
    PriceMode,
    TradeInstruction,
    TradeSide,
    TxResult,
    TxStatus,
    derive_side_from_action,
)

from .interfaces import BaseExecutionGateway


class CCXTExecutionGateway(BaseExecutionGateway):
    """Async execution gateway using CCXT unified API for real exchanges.

    Features:
    - Supports spot, futures, and perpetual contracts
    - Automatic leverage and margin mode setup
    - Symbol format normalization (BTC-USD -> BTC/USD:USD for futures)
    - Proper error handling and partial fill support
    - Fee tracking from exchange responses
    """

    def __init__(
        self,
        exchange_id: str,
        api_key: str = "",
        secret_key: str = "",
        passphrase: Optional[str] = None,
        wallet_address: Optional[str] = None,
        private_key: Optional[str] = None,
        testnet: bool = False,
        default_type: str = "swap",
        margin_mode: str = "cross",
        position_mode: str = "oneway",
        ccxt_options: Optional[Dict] = None,
    ) -> None:
        """Initialize CCXT exchange gateway.

        Args:
            exchange_id: Exchange identifier (e.g., 'binance', 'okx', 'bybit', 'hyperliquid')
            api_key: API key for authentication (not required for Hyperliquid)
            secret_key: Secret key for authentication (not required for Hyperliquid)
            passphrase: Optional passphrase (required for OKX, Coinbase Exchange)
            wallet_address: Wallet address (required for Hyperliquid)
            private_key: Private key (required for Hyperliquid)
            testnet: Whether to use testnet/sandbox mode
            default_type: Default market type ('spot', 'future', 'swap', "margin")
            margin_mode: Default margin mode ('isolated' or 'cross')
            position_mode: Position mode ('oneway' or 'hedged'), default 'oneway'
            ccxt_options: Additional CCXT exchange options
        """
        self.exchange_id = exchange_id.lower()
        self.api_key = api_key
        self.secret_key = secret_key
        self.passphrase = passphrase
        self.wallet_address = wallet_address
        self.private_key = private_key
        self.testnet = testnet
        self.default_type = default_type
        self.margin_mode = margin_mode
        self.position_mode = position_mode
        self._ccxt_options = ccxt_options or {}

        # Track leverage settings per symbol to avoid redundant calls
        self._leverage_cache: Dict[str, float] = {}
        self._margin_mode_cache: Dict[str, str] = {}

        # Exchange instance (lazy-initialized)
        self._exchange: Optional[ccxt.Exchange] = None

    def _choose_default_type_for_exchange(self) -> str:
        """Return a safe defaultType for the selected exchange.

        - Binance: map 'swap' to 'future' (USDT-M futures)
        - Others: keep configured default_type
        """
        if self.exchange_id == "binance" and self.default_type == "swap":
            return "future"
        return self.default_type

    async def _get_exchange(self) -> ccxt.Exchange:
        """Get or create the CCXT exchange instance."""
        if self._exchange is not None:
            return self._exchange

        # Get exchange class by name
        try:
            exchange_class = getattr(ccxt, self.exchange_id)
        except AttributeError:
            raise ValueError(
                f"Exchange '{self.exchange_id}' not supported by CCXT. "
                f"Available: {', '.join(ccxt.exchanges)}"
            )

        # Build configuration based on exchange type
        config = {
            "enableRateLimit": True,  # Respect rate limits
            "options": {
                "defaultType": self._choose_default_type_for_exchange(),
                **self._ccxt_options,
            },
        }

        # Hyperliquid uses wallet-based authentication
        if self.exchange_id == "hyperliquid":
            if self.wallet_address:
                config["walletAddress"] = self.wallet_address
            if self.private_key:
                config["privateKey"] = self.private_key
            # Disable builder fees by default (can be overridden in ccxt_options)
            if "builderFee" not in config["options"]:
                config["options"]["builderFee"] = False
            if "approvedBuilderFee" not in config["options"]:
                config["options"]["approvedBuilderFee"] = False
        else:
            # Standard API key/secret authentication
            config["apiKey"] = self.api_key
            config["secret"] = self.secret_key

            # Add passphrase if provided (required for OKX, Coinbase Exchange)
            if self.passphrase:
                config["password"] = self.passphrase

        # Create exchange instance
        self._exchange = exchange_class(config)

        # Enable sandbox/testnet mode if requested
        if self.testnet:
            self._exchange.set_sandbox_mode(True)

        # Optionally set position mode (oneway/hedged) for exchanges that support it
        try:
            if self._exchange.has.get("setPositionMode"):
                hedged = self.position_mode.lower() in ("hedged", "dual", "hedge")
                await self._exchange.set_position_mode(hedged)
        except Exception as e:
            logger.warning(
                f"⚠️ Could not set position mode ({self.position_mode}) on {self.exchange_id}: {e}"
            )

        # Load markets
        try:
            await self._exchange.load_markets()
        except Exception as e:
            raise RuntimeError(
                f"Failed to load markets for {self.exchange_id}: {e}"
            ) from e

        return self._exchange

    def _normalize_symbol(self, symbol: str, market_type: Optional[str] = None) -> str:
        """Normalize symbol format for CCXT.

        Examples:
            BTC-USD -> BTC/USD (spot)
            BTC-USDT -> BTC/USDT:USDT (USDT futures on colon exchanges)
            ETH-USD -> ETH/USD:USD (USD futures on colon exchanges)

        Args:
            symbol: Symbol in format 'BTC-USD', 'BTC-USDT', etc.
            market_type: Optional market type override ('spot', 'future', 'swap')

        Returns:
            Normalized CCXT symbol
        """
        mtype = market_type or self.default_type

        # Replace dash with slash
        base_symbol = symbol.replace("-", "/")

        # For futures/swap, only append settlement currency for non-Binance exchanges
        if mtype in ("future", "swap") and self.exchange_id not in ("binance",):
            if ":" not in base_symbol:
                parts = base_symbol.split("/")
                if len(parts) == 2:
                    base_symbol = f"{parts[0]}/{parts[1]}:{parts[1]}"

        return base_symbol

    async def _setup_leverage(
        self, symbol: str, leverage: Optional[float], exchange: ccxt.Exchange