import { X, ExternalLink, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useState } from "react";

interface DataNode {
  id: string;
  name: string;
  type: "source" | "adapter" | "api" | "frontend";
  category?: string;
  description: string;
  endpoints?: string[];
  methods?: string[];
  connections: string[];
  color: string;
  icon: any;
}

interface DetailPanelProps {
  node: DataNode | null;
  onClose: () => void;
}

const getGitHubUrl = (node: DataNode): string => {
  const baseUrl = "https://github.com/ValueCell-ai/valuecell/tree/main";
  
  if (node.type === "source") {
    if (node.id === "yfinance") return `${baseUrl}/python/valuecell/adapters/assets/yfinance_adapter.py`;
    if (node.id === "akshare") return `${baseUrl}/python/valuecell/adapters/assets/akshare_adapter.py`;
    if (node.id === "baostock") return `${baseUrl}/python/valuecell/adapters/assets/baostock_adapter.py`;
    if (node.id === "ccxt") return `${baseUrl}/python/valuecell/agents/common/trading/execution/ccxt_trading.py`;
    if (node.id === "rootdata") return `${baseUrl}/python/valuecell/agents/sources/rootdata.py`;
    if (node.id === "cninfo") return `${baseUrl}/python/valuecell/agents/research_agent/sources.py`;
  }
  
  if (node.type === "adapter") {
    if (node.id.includes("adapter")) {
      const adapterName = node.id.replace("-adapter", "");
      return `${baseUrl}/python/valuecell/adapters/assets/${adapterName}_adapter.py`;
    }
    if (node.id === "ccxt-gateway") return `${baseUrl}/python/valuecell/agents/common/trading/execution/ccxt_trading.py`;
    if (node.id === "asset-service") return `${baseUrl}/python/valuecell/server/services/assets/asset_service.py`;
  }
  
  if (node.type === "api") {
    if (node.id === "watchlist-api") return `${baseUrl}/python/valuecell/server/api/routers/watchlist.py`;
    if (node.id === "agent-api") return `${baseUrl}/python/valuecell/server/api/routers/agent.py`;
    if (node.id === "conversation-api") return `${baseUrl}/python/valuecell/server/api/routers/conversation.py`;
    if (node.id === "models-api") return `${baseUrl}/python/valuecell/server/api/routers/models.py`;
    if (node.id === "strategy-api") return `${baseUrl}/python/valuecell/server/api/routers/strategy.py`;
  }
  
  return baseUrl;
};

const getCodeExample = (node: DataNode): string => {
  if (node.type === "api" && node.endpoints && node.endpoints.length > 0) {
    const endpoint = node.endpoints[0];
    const method = endpoint.split(" ")[0];
    const path = endpoint.split(" ")[1] || endpoint;
    
    return `# Example: ${node.name}
import requests

BASE_URL = "https://backend.valuecell.ai/api/v1"

# ${endpoint}
response = requests.${method.toLowerCase()}(
    f"{BASE_URL}${path}",
    headers={"Content-Type": "application/json"}
)

data = response.json()
print(data)`;
  }
  
  if (node.type === "adapter") {
    return `# Example: ${node.name}
from valuecell.adapters.assets import ${node.id.replace("-", "_")}

# Initialize adapter
adapter = ${node.name.replace(" ", "")}()

# Use adapter methods
${node.methods?.slice(0, 2).map(m => `# ${m}`).join("\n") || "# Adapter methods available"}`;
  }
  
  if (node.type === "source") {
    if (node.id === "yfinance") {
      return `# Example: Yahoo Finance via yfinance
import yfinance as yf

# Get stock data
ticker = yf.Ticker("AAPL")
info = ticker.info
history = ticker.history(period="1mo")

print(f"Price: {info['currentPrice']}")
print(history.tail())`;
    }
    
    if (node.id === "ccxt") {
      return `# Example: CCXT for crypto exchanges
import ccxt

# Initialize exchange
exchange = ccxt.binance({
    'apiKey': 'YOUR_API_KEY',
    'secret': 'YOUR_SECRET',
})

# Fetch ticker
ticker = exchange.fetch_ticker('BTC/USDT')
print(f"BTC Price: {ticker['last']}")`;
    }
  }
  
  return `# ${node.name}
# ${node.description}

${node.methods?.map(m => `# - ${m}`).join("\n") || ""}`;
};

export default function DetailPanel({ node, onClose }: DetailPanelProps) {
  const [copiedCode, setCopiedCode] = useState(false);

  if (!node) return null;

  const githubUrl = getGitHubUrl(node);
  const codeExample = getCodeExample(node);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(codeExample);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 animate-in fade-in duration-200"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="fixed right-0 top-0 bottom-0 w-full md:w-[600px] bg-card border-l border-border z-50 animate-in slide-in-from-right duration-300">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-start justify-between p-6 border-b border-border">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <node.icon className="w-6 h-6" style={{ color: node.color }} />
                <h2 className="text-2xl font-bold">{node.name}</h2>
              </div>
              <div className="flex items-center gap-2 mb-3">
                <Badge variant="outline" style={{ borderColor: node.color }}>
                  {node.type}
                </Badge>
                {node.category && (
                  <Badge variant="secondary">{node.category}</Badge>
                )}
              </div>
              <p className="text-muted-foreground">{node.description}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="ml-4"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Content */}
          <ScrollArea className="flex-1">
            <div className="p-6 space-y-6">
              {/* Endpoints/Methods Section */}
              {node.endpoints && node.endpoints.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold mb-3">API Endpoints</h3>
                  <div className="space-y-2">
                    {node.endpoints.map((endpoint, idx) => {
                      const [method, path] = endpoint.split(" ");
                      return (
                        <div
                          key={idx}
                          className="flex items-center gap-3 p-3 bg-secondary rounded-lg font-mono text-sm"
                        >
                          <Badge
                            variant="outline"
                            className="font-bold"
                            style={{
                              borderColor: method === "GET" ? "oklch(0.55 0.16 160)" : 
                                          method === "POST" ? "oklch(0.55 0.18 264)" :
                                          method === "DELETE" ? "oklch(0.577 0.245 27.325)" :
                                          "oklch(0.65 0.15 45)"
                            }}
                          >
                            {method}
                          </Badge>
                          <code className="flex-1 text-foreground">{path || endpoint}</code>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {node.methods && node.methods.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold mb-3">
                    {node.type === "source" ? "Data Capabilities" : "Methods"}
                  </h3>
                  <div className="space-y-2">
                    {node.methods.map((method, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-3 p-3 bg-secondary rounded-lg"
                      >
                        <div className="w-2 h-2 rounded-full mt-2" style={{ backgroundColor: node.color }} />
                        <span className="flex-1 text-sm">{method}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Connections */}
              {node.connections.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold mb-3">Connected Components</h3>
                  <div className="flex flex-wrap gap-2">
                    {node.connections.map((connId, idx) => (
                      <Badge key={idx} variant="outline">
                        {connId.replace(/-/g, " ").replace(/\b\w/g, l => l.toUpperCase())}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Code Example */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-bold">Code Example</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyCode}
                    className="gap-2"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="w-4 h-4" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>
                <div className="relative">
                  <pre className="p-4 bg-secondary rounded-lg overflow-x-auto text-sm font-mono">
                    <code className="text-foreground">{codeExample}</code>
                  </pre>
                </div>
              </div>

              {/* GitHub Link */}
              <div>
                <h3 className="text-lg font-bold mb-3">Source Code</h3>
                <a
                  href={githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-4 bg-secondary hover:bg-secondary/80 rounded-lg transition-colors group"
                >
                  <ExternalLink className="w-5 h-5 text-primary" />
                  <div className="flex-1">
                    <div className="font-medium group-hover:text-primary transition-colors">
                      View on GitHub
                    </div>
                    <div className="text-xs text-muted-foreground font-mono truncate">
                      {githubUrl.replace("https://github.com/", "")}
                    </div>
                  </div>
                </a>
              </div>
            </div>
          </ScrollArea>
        </div>
      </div>
    </>
  );
}
