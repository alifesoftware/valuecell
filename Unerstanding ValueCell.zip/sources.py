        session: aiohttp session

    Returns:
        Optional[str]: The correct orgId, or None if not found
    """
    search_url = "http://www.cninfo.com.cn/new/information/topSearch/query"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Host": "www.cninfo.com.cn",
        "Origin": "http://www.cninfo.com.cn",
        "Referer": "http://www.cninfo.com.cn/new/commonUrl/pageOfSearch?url=disclosure/list/search&lastPage=index",
        "X-Requested-With": "XMLHttpRequest",
    }

    search_data = {"keyWord": stock_code}

    try:
        async with session.post(
            search_url, headers=headers, data=search_data
        ) as response:
            if response.status == 200:
                result = await response.json()

                if result and len(result) > 0:
                    # Find the exact match for the stock code
                    for company_info in result:
                        if company_info.get("code") == stock_code:
                            return company_info.get("orgId")

                    # If no exact match, return the first result's orgId
                    return result[0].get("orgId")

    except Exception as e:
        print(f"Error getting orgId for {stock_code}: {e}")

    return None


async def _fetch_cninfo_data(
    stock_code: str,
    report_types: List[str],
    years: List[int],
    quarters: List[int],
    limit: int,
) -> List[dict]:
    """Fetch real A-share filing data from CNINFO API

    Args:
        stock_code: Normalized stock code
        report_types: List of report types
        years: List of years
        quarters: List of quarters (1-4), empty list means all quarters
        limit: Maximum number of records to fetch

    Returns:
        List[dict]: List of filing data
    """

    # CNINFO API configuration
    base_url = "http://www.cninfo.com.cn/new/hisAnnouncement/query"

    # Request headers configuration
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Host": "www.cninfo.com.cn",
        "Origin": "http://www.cninfo.com.cn",
        "Referer": "http://www.cninfo.com.cn/new/commonUrl/pageOfSearch?url=disclosure/list/search&lastPage=index",
        "X-Requested-With": "XMLHttpRequest",
    }

    # Report type mapping (supports both English and Chinese for backward compatibility)
    category_mapping = {
        "annual": "category_ndbg_szsh",
        "semi-annual": "category_bndbg_szsh",
        "quarterly": "category_sjdbg_szsh",
    }

    # Determine exchange
    column = "szse" if stock_code.startswith(("000", "002", "300")) else "sse"