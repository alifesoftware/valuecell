/**
 * Design Philosophy: Information Architecture meets Swiss Design
 * - Hierarchical clarity through structured grid systems
 * - Technical color palette: Navy background, gold (market), blue (APIs), emerald (adapters)
 * - Vertical flow layout with animated connections
 * - Typography: Space Grotesk (headers), Inter (body), JetBrains Mono (technical)
 */

import { useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Database, GitBranch, Server, Globe, ArrowDown, ExternalLink, Search, X } from "lucide-react";
import DetailPanel from "@/components/DetailPanel";
import ConnectionLines from "@/components/ConnectionLines";

interface DataNode {
  id: string;
  name: string;
  type: "source" | "adapter" | "api" | "frontend";
  category?: string;
  description: string;
  endpoints?: string[];
  methods?: string[];
  connections: string[];
  color: string;
  icon: any;
}

const dataNodes: DataNode[] = [
  // Data Sources
  {
    id: "yfinance",
    name: "Yahoo Finance",
    type: "source",
    category: "US & International Markets",
    description: "Real-time and historical stock data via yfinance library",
    methods: ["Stock quotes", "Historical OHLCV", "Company info", "Market cap"],
    connections: ["yfinance-adapter"],
    color: "oklch(0.65 0.15 45)",
    icon: Database,
  },
  {
    id: "akshare",
    name: "AKShare",
    type: "source",
    category: "Chinese Markets",
    description: "Comprehensive Chinese market data (SSE, SZSE, HKEX)",
    methods: ["A-share data", "HK stocks", "Real-time quotes", "Market indices"],
    connections: ["akshare-adapter"],
    color: "oklch(0.65 0.15 45)",
    icon: Database,
  },
  {
    id: "baostock",
    name: "BaoStock",
    type: "source",
    category: "Chinese Markets",
    description: "Historical A-share data for SSE and SZSE",
    methods: ["Historical K-line", "Daily data", "Intraday data"],
    connections: ["baostock-adapter"],
    color: "oklch(0.65 0.15 45)",
    icon: Database,
  },
  {
    id: "ccxt",
    name: "CCXT / CCXT Pro",
    type: "source",
    category: "Cryptocurrency",
    description: "Unified API for crypto exchanges with WebSocket support",
    methods: ["Exchange data", "Real-time WebSocket", "Order execution", "Balance queries"],
    connections: ["ccxt-gateway"],
    color: "oklch(0.65 0.15 45)",
    icon: Database,
  },
  {
    id: "rootdata",
    name: "RootData",
    type: "source",
    category: "Cryptocurrency",
    description: "Web scraping for crypto project intelligence",
    methods: ["Project data", "Tokenomics", "VC funding", "Social metrics"],
    connections: ["rootdata-scraper"],
    color: "oklch(0.65 0.15 45)",
    icon: Database,
  },
  {
    id: "cninfo",
    name: "CNINFO",
    type: "source",
    category: "Chinese Markets",
    description: "Official Chinese securities regulatory filings",
    methods: ["Company filings", "Annual reports", "Announcements"],
    connections: ["research-agent"],
    color: "oklch(0.65 0.15 45)",
    icon: Database,
  },
  
  // Adapters
  {
    id: "yfinance-adapter",
    name: "YFinance Adapter",
    type: "adapter",
    description: "Normalizes Yahoo Finance data to internal format",
    methods: ["Ticker conversion", "Exchange mapping", "Data normalization"],
    connections: ["asset-service"],
    color: "oklch(0.55 0.16 160)",
    icon: GitBranch,
  },
  {
    id: "akshare-adapter",
    name: "AKShare Adapter",
    type: "adapter",
    description: "Handles Chinese market data normalization",
    methods: ["Field mapping", "Currency conversion", "Market type detection"],
    connections: ["asset-service"],
    color: "oklch(0.55 0.16 160)",
    icon: GitBranch,
  },
  {
    id: "baostock-adapter",
    name: "BaoStock Adapter",
    type: "adapter",
    description: "Manages BaoStock authentication and data retrieval",
    methods: ["Session management", "Interval mapping", "Historical data"],
    connections: ["asset-service"],
    color: "oklch(0.55 0.16 160)",
    icon: GitBranch,
  },
  {
    id: "ccxt-gateway",
    name: "CCXT Gateway",
    type: "adapter",
    description: "Execution gateway for crypto exchanges",
    methods: ["Order execution", "Balance queries", "Position management"],
    connections: ["strategy-api"],
    color: "oklch(0.55 0.16 160)",
    icon: GitBranch,
  },
  {
    id: "rootdata-scraper",
    name: "RootData Scraper",
    type: "adapter",
    description: "Playwright-based web scraping for crypto projects",
    methods: ["DOM parsing", "Data extraction", "Project profiling"],
    connections: ["research-agent"],
    color: "oklch(0.55 0.16 160)",
    icon: GitBranch,
  },
  {
    id: "asset-service",
    name: "Asset Service",
    type: "adapter",
    description: "Central service coordinating all asset data adapters",
    methods: ["Adapter selection", "Data aggregation", "Caching"],
    connections: ["watchlist-api"],
    color: "oklch(0.55 0.16 160)",
    icon: Server,
  },
  {
    id: "research-agent",
    name: "Research Agent",
    type: "adapter",
    description: "Aggregates research data from multiple sources",
    methods: ["Document retrieval", "Analysis", "Report generation"],
    connections: ["agent-api"],
    color: "oklch(0.55 0.16 160)",
    icon: Server,
  },
  
  // Backend APIs
  {
    id: "watchlist-api",
    name: "Watchlist API",
    type: "api",
    description: "Asset search, pricing, and watchlist management",
    endpoints: [
      "GET /asset/search",
      "GET /asset/{ticker}",
      "GET /asset/{ticker}/price",
      "GET /asset/{ticker}/price/historical",
      "POST /asset",
      "DELETE /asset/{ticker}",
    ],
    connections: ["frontend"],
    color: "oklch(0.55 0.18 264)",
    icon: Server,
  },
  {
    id: "agent-api",
    name: "Agent API",
    type: "api",
    description: "Autonomous agent lifecycle management",
    endpoints: [
      "GET /",
      "GET /{agent_id}",
      "GET /by-name/{agent_name}",
      "POST /{agent_name}/enable",
    ],
    connections: ["frontend"],
    color: "oklch(0.55 0.18 264)",
    icon: Server,
  },
  {
    id: "conversation-api",
    name: "Conversation API",
    type: "api",
    description: "Chat history and scheduled task management",
    endpoints: [
      "GET /",
      "GET /{conversation_id}/history",
      "DELETE /{conversation_id}",
      "GET /scheduled-task-results",
    ],
    connections: ["frontend"],
    color: "oklch(0.55 0.18 264)",
    icon: Server,
  },
  {
    id: "models-api",
    name: "Model Provider API",
    type: "api",
    description: "LLM provider configuration",
    endpoints: [
      "GET /providers",
      "PUT /providers/{provider}/config",
      "POST /providers/{provider}/models",
      "PUT /providers/default",
    ],
    connections: ["frontend"],
    color: "oklch(0.55 0.18 264)",
    icon: Server,
  },
  {
    id: "strategy-api",
    name: "Strategy API",
    type: "api",
    description: "Trading strategy management and monitoring",
    endpoints: [
      "GET /",
      "GET /performance",
      "GET /holding",
      "POST /stop",
    ],
    connections: ["frontend"],
    color: "oklch(0.55 0.18 264)",
    icon: Server,
  },
  
  // Frontend
  {
    id: "frontend",
    name: "Frontend Application",
    type: "frontend",
    description: "React-based user interface",
    methods: ["User interactions", "Data visualization", "Real-time updates"],
    connections: [],
    color: "oklch(0.75 0.1 264)",
    icon: Globe,
  },
];

export default function Home() {
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [detailNode, setDetailNode] = useState<DataNode | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilters, setActiveFilters] = useState<Set<string>>(new Set());

  const getConnectedNodes = (nodeId: string): Set<string> => {
    const connected = new Set<string>();
    const node = dataNodes.find(n => n.id === nodeId);
    
    if (!node) return connected;
    
    // Add direct connections
    node.connections.forEach(id => connected.add(id));
    
    // Add reverse connections (nodes that connect to this one)
    dataNodes.forEach(n => {
      if (n.connections.includes(nodeId)) {
        connected.add(n.id);
      }
    });
    
    return connected;
  };

  const isHighlighted = (nodeId: string): boolean => {
    if (!hoveredNode && !selectedNode) return false;
    const activeNode = selectedNode || hoveredNode;
    if (activeNode === nodeId) return true;
    return getConnectedNodes(activeNode!).has(nodeId);
  };

  // Filter logic
  const filteredNodes = useMemo(() => {
    return dataNodes.filter(node => {
      // Search filter
      const matchesSearch = searchQuery === "" || 
        node.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        node.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        node.category?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        node.methods?.some(m => m.toLowerCase().includes(searchQuery.toLowerCase())) ||
        node.endpoints?.some(e => e.toLowerCase().includes(searchQuery.toLowerCase()));
      
      // Type filter
      const matchesFilter = activeFilters.size === 0 || 
        activeFilters.has(node.type) ||
        (node.category && activeFilters.has(node.category));
      
      return matchesSearch && matchesFilter;
    });
  }, [searchQuery, activeFilters]);

  const sources = filteredNodes.filter(n => n.type === "source");
  const adapters = filteredNodes.filter(n => n.type === "adapter");
  const apis = filteredNodes.filter(n => n.type === "api");
  const frontend = filteredNodes.find(n => n.type === "frontend");

  const toggleFilter = (filter: string) => {
    const newFilters = new Set(activeFilters);
    if (newFilters.has(filter)) {
      newFilters.delete(filter);
    } else {
      newFilters.add(filter);
    }
    setActiveFilters(newFilters);
  };

  const clearFilters = () => {
    setSearchQuery("");
    setActiveFilters(new Set());
  };

  const hasActiveFilters = searchQuery !== "" || activeFilters.size > 0;
  const totalResults = filteredNodes.length;

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      {/* Connection Lines */}
      <ConnectionLines
        nodes={dataNodes}
        hoveredNode={hoveredNode}
        selectedNode={selectedNode}
        getConnectedNodes={getConnectedNodes}
      />
      {/* Header */}
      <header className="border-b border-border bg-card relative z-10">
        <div className="container py-8">
          <h1 className="text-4xl font-bold mb-2">ValueCell Data Flow Architecture</h1>
          <p className="text-muted-foreground text-lg">
            Interactive visualization of financial data sources, adapters, and API endpoints
          </p>
        </div>
      </header>

      {/* Search and Filter Bar */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-20">
        <div className="container py-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search Input */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search components, endpoints, or methods..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-10"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Filter Buttons */}
            <div className="flex flex-wrap gap-2">
              <Button
                variant={activeFilters.has("source") ? "default" : "outline"}
                size="sm"
                onClick={() => toggleFilter("source")}
              >
                <Database className="w-4 h-4 mr-2" />
                Sources
              </Button>
              <Button
                variant={activeFilters.has("adapter") ? "default" : "outline"}
                size="sm"
                onClick={() => toggleFilter("adapter")}
              >
                <GitBranch className="w-4 h-4 mr-2" />
                Adapters
              </Button>
              <Button
                variant={activeFilters.has("api") ? "default" : "outline"}
                size="sm"
                onClick={() => toggleFilter("api")}
              >
                <Server className="w-4 h-4 mr-2" />
                APIs
              </Button>
              <Button
                variant={activeFilters.has("US & International Markets") ? "default" : "outline"}
                size="sm"
                onClick={() => toggleFilter("US & International Markets")}
              >
                US Markets
              </Button>
              <Button
                variant={activeFilters.has("Chinese Markets") ? "default" : "outline"}
                size="sm"
                onClick={() => toggleFilter("Chinese Markets")}
              >
                Chinese Markets
              </Button>
              <Button
                variant={activeFilters.has("Cryptocurrency") ? "default" : "outline"}
                size="sm"
                onClick={() => toggleFilter("Cryptocurrency")}
              >
                Crypto
              </Button>
              {hasActiveFilters && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="text-muted-foreground"
                >
                  <X className="w-4 h-4 mr-2" />
                  Clear All
                </Button>
              )}
            </div>
          </div>

          {/* Results Counter */}
          {hasActiveFilters && (
            <div className="mt-4 text-sm text-muted-foreground">
              Showing {totalResults} of {dataNodes.length} components
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <main className="container py-12 relative z-10">
        {/* Empty State */}
        {totalResults === 0 && (
          <div className="text-center py-16">
            <Search className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-bold mb-2">No components found</h3>
            <p className="text-muted-foreground mb-6">
              Try adjusting your search or filters
            </p>
            <Button onClick={clearFilters} variant="outline">
              Clear all filters
            </Button>
          </div>
        )}

        {totalResults > 0 && (
        <div className="space-y-16">
          {/* Data Sources Layer */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <Database className="w-6 h-6" style={{ color: "oklch(0.65 0.15 45)" }} />
              <h2 className="text-2xl font-bold">Data Sources</h2>
              <Badge variant="outline" className="ml-auto">Layer 1</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {sources.map((node) => (
                <Card
                  key={node.id}
                  id={`node-${node.id}`}
                  className={`p-6 cursor-pointer transition-all duration-200 ${
                    isHighlighted(node.id)
                      ? "ring-2 scale-105 shadow-lg"
                      : "opacity-60 hover:opacity-100"
                  }`}
                  style={{
                    borderColor: node.color,
                  }}
                  onMouseEnter={() => setHoveredNode(node.id)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onClick={() => {
                    setSelectedNode(selectedNode === node.id ? null : node.id);
                    setDetailNode(node);
                  }}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <node.icon className="w-5 h-5 mt-1" style={{ color: node.color }} />
                    <div className="flex-1">
                      <h3 className="font-bold text-lg mb-1">{node.name}</h3>
                      {node.category && (
                        <Badge variant="secondary" className="text-xs mb-2">
                          {node.category}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{node.description}</p>
                  {node.methods && (
                    <div className="space-y-1">
                      {node.methods.slice(0, 3).map((method, idx) => (
                        <div key={idx} className="text-xs font-mono text-muted-foreground">
                          • {method}
                        </div>
                      ))}
                    </div>
                  )}
                </Card>
              ))}
            </div>
          </section>

          {/* Connection Arrow */}
          <div className="flex justify-center">
            <ArrowDown className="w-8 h-8 text-muted-foreground animate-bounce" />
          </div>

          {/* Adapters Layer */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <GitBranch className="w-6 h-6" style={{ color: "oklch(0.55 0.16 160)" }} />
              <h2 className="text-2xl font-bold">Adapters & Services</h2>
              <Badge variant="outline" className="ml-auto">Layer 2</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {adapters.map((node) => (
                <Card
                  key={node.id}
                  id={`node-${node.id}`}
                  className={`p-6 cursor-pointer transition-all duration-200 ${
                    isHighlighted(node.id)
                      ? "ring-2 scale-105 shadow-lg"
                      : "opacity-60 hover:opacity-100"
                  }`}
                  style={{
                    borderColor: node.color,
                  }}
                  onMouseEnter={() => setHoveredNode(node.id)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onClick={() => {
                    setSelectedNode(selectedNode === node.id ? null : node.id);
                    setDetailNode(node);
                  }}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <node.icon className="w-5 h-5 mt-1" style={{ color: node.color }} />
                    <div className="flex-1">
                      <h3 className="font-bold text-lg mb-1">{node.name}</h3>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{node.description}</p>
                  {node.methods && (
                    <div className="space-y-1">
                      {node.methods.map((method, idx) => (
                        <div key={idx} className="text-xs font-mono text-muted-foreground">
                          • {method}
                        </div>
                      ))}
                    </div>
                  )}
                </Card>
              ))}
            </div>
          </section>

          {/* Connection Arrow */}
          <div className="flex justify-center">
            <ArrowDown className="w-8 h-8 text-muted-foreground animate-bounce" />
          </div>

          {/* Backend APIs Layer */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <Server className="w-6 h-6" style={{ color: "oklch(0.55 0.18 264)" }} />
              <h2 className="text-2xl font-bold">Backend APIs</h2>
              <Badge variant="outline" className="ml-auto">Layer 3</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {apis.map((node) => (
                <Card
                  key={node.id}
                  id={`node-${node.id}`}
                  className={`p-6 cursor-pointer transition-all duration-200 ${
                    isHighlighted(node.id)
                      ? "ring-2 scale-105 shadow-lg"
                      : "opacity-60 hover:opacity-100"
                  }`}
                  style={{
                    borderColor: node.color,
                  }}
                  onMouseEnter={() => setHoveredNode(node.id)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onClick={() => {
                    setSelectedNode(selectedNode === node.id ? null : node.id);
                    setDetailNode(node);
                  }}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <node.icon className="w-5 h-5 mt-1" style={{ color: node.color }} />
                    <div className="flex-1">
                      <h3 className="font-bold text-lg mb-1">{node.name}</h3>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{node.description}</p>
                  {node.endpoints && (
                    <div className="space-y-1">
                      {node.endpoints.slice(0, 4).map((endpoint, idx) => (
                        <div key={idx} className="text-xs font-mono text-muted-foreground">
                          {endpoint}
                        </div>
                      ))}
                      {node.endpoints.length > 4 && (
                        <div className="text-xs text-muted-foreground italic">
                          +{node.endpoints.length - 4} more endpoints
                        </div>
                      )}
                    </div>
                  )}
                </Card>
              ))}
            </div>
          </section>

          {/* Connection Arrow */}
          <div className="flex justify-center">
            <ArrowDown className="w-8 h-8 text-muted-foreground animate-bounce" />
          </div>

          {/* Frontend Layer */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <Globe className="w-6 h-6" style={{ color: "oklch(0.75 0.1 264)" }} />
              <h2 className="text-2xl font-bold">Frontend Application</h2>
              <Badge variant="outline" className="ml-auto">Layer 4</Badge>
            </div>
            {frontend && (
              <Card
                id={`node-${frontend.id}`}
                className={`p-8 max-w-2xl mx-auto cursor-pointer transition-all duration-200 ${
                  isHighlighted(frontend.id)
                    ? "ring-2 scale-105 shadow-lg"
                    : "opacity-60 hover:opacity-100"
                }`}
                style={{
                  borderColor: frontend.color,
                }}
                onMouseEnter={() => setHoveredNode(frontend.id)}
                onMouseLeave={() => setHoveredNode(null)}
                onClick={() => {
                  setSelectedNode(selectedNode === frontend.id ? null : frontend.id);
                  setDetailNode(frontend);
                }}
              >
                <div className="flex items-start gap-4 mb-4">
                  <frontend.icon className="w-8 h-8 mt-1" style={{ color: frontend.color }} />
                  <div className="flex-1">
                    <h3 className="font-bold text-2xl mb-2">{frontend.name}</h3>
                    <p className="text-muted-foreground">{frontend.description}</p>
                  </div>
                </div>
                {frontend.methods && (
                  <div className="grid grid-cols-3 gap-4 mt-4">
                    {frontend.methods.map((method, idx) => (
                      <div key={idx} className="text-sm text-center p-3 bg-secondary rounded">
                        {method}
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            )}
          </section>
        </div>
        )}

        {/* Legend */}
        <div className="mt-16 p-6 bg-card rounded-lg border border-border">
          <h3 className="font-bold text-lg mb-4">Interaction Guide</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: "oklch(0.65 0.15 45)" }} />
              <span>Data Sources (External APIs & Libraries)</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: "oklch(0.55 0.16 160)" }} />
              <span>Adapters & Services (Data Normalization)</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: "oklch(0.55 0.18 264)" }} />
              <span>Backend APIs (REST Endpoints)</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: "oklch(0.75 0.1 264)" }} />
              <span>Frontend (User Interface)</span>
            </div>
          </div>
          <p className="mt-4 text-muted-foreground text-sm">
            <strong>Hover</strong> over any component to highlight its connections. <strong>Click</strong> to lock the selection.
          </p>
        </div>

        {/* Footer */}
        <footer className="mt-16 text-center text-sm text-muted-foreground">
          <p className="flex items-center justify-center gap-2">
            Generated from ValueCell repository analysis
            <a
              href="https://github.com/ValueCell-ai/valuecell"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-primary hover:underline"
            >
              <ExternalLink className="w-3 h-3" />
              View on GitHub
            </a>
          </p>
        </footer>
      </main>

      {/* Detail Panel */}
      <DetailPanel node={detailNode} onClose={() => setDetailNode(null)} />
    </div>
  );
}
