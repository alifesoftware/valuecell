RootData API Client - Cryptocurrency projects, VCs and people data fetching tool

Extracts comprehensive data from RootData using Playwright browser automation to access
server-side rendered (SSR) data from window.__NUXT__ object.

Features:
---------
- **Rich Project Details**: Get 40+ fields including price, market cap, supply,
  historical prices, contracts, social links, and community sentiment
- **Smart Search**: Search projects by name or keyword with browser interaction
- **VC & People Data**: Search and retrieve venture capital firms and people information
- **Fallback Support**: Automatic fallback to HTML parsing if Playwright unavailable

Quick Start:
------------
```python
import asyncio
from valuecell.agents.sources.rootdata import (
    search_projects,
    get_project_detail
)

async def main():
    # Search for projects
    projects = await search_projects("Aster", limit=10)
    for project in projects:
        print(f"{project.name} ({project.token_symbol})")

    # Get detailed information
    if projects:
        detail = await get_project_detail(projects[0].id)
        print(f"Price: ${detail.token_price}")
        print(f"Market Cap: ${detail.market_cap}")
        print(f"24h Change: {detail.price_change_24h}%")
        print(f"Ecosystems: {', '.join(detail.ecosystems)}")
        print(f"Contracts: {detail.contracts}")
        print(f"Community Hold: {detail.hold_percentage}%")

asyncio.run(main())
```

Requirements:
-------------
- playwright: `pip install playwright && playwright install chromium`
- httpx: `pip install httpx`
- beautifulsoup4: `pip install beautifulsoup4`
"""

import re
from typing import Any, Dict, List, Optional

import httpx
from bs4 import BeautifulSoup
from loguru import logger
from pydantic import BaseModel, Field

# ============================================================================
# Data Models
# ============================================================================


class RootDataProject(BaseModel):
    """Cryptocurrency project information"""

    # Basic Info
    id: int
    name: str
    brief_intro: str = Field(default="", description="Brief introduction")
    description: str = Field(default="", description="Detailed description")
    image_url: Optional[str] = Field(None, description="Project logo")
    founded_year: Optional[int] = Field(None, description="Founded year")

    # Status
    status: Optional[str] = Field(None, description="Project status (Active/Inactive)")
    level: Optional[int] = Field(None, description="Project level/tier")
    rank: Optional[int] = Field(None, description="Project rank")

    # Tags and Categories
    tags: List[str] = Field(default_factory=list, description="Project tags")
    ecosystems: List[str] = Field(
        default_factory=list, description="Blockchain ecosystems"
    )

    # Token Information
    token_symbol: Optional[str] = Field(None, description="Token symbol")
    token_price: Optional[float] = Field(None, description="Current token price")
    market_cap: Optional[float] = Field(None, description="Market capitalization")
    fdv: Optional[float] = Field(None, description="Fully diluted valuation")
    volume_24h: Optional[float] = Field(None, description="24h trading volume")
    volume_change_24h: Optional[float] = Field(None, description="24h volume change")

    # Supply Information
    circulating_supply: Optional[float] = Field(None, description="Circulating supply")
    total_supply: Optional[float] = Field(None, description="Total supply")
    max_supply: Optional[float] = Field(None, description="Maximum supply")

    # Price Changes
    price_change_1h: Optional[float] = Field(None, description="1h price change %")
    price_change_24h: Optional[float] = Field(None, description="24h price change %")