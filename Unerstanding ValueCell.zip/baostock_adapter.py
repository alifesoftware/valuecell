from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from time import time
from typing import Any, Callable, List, Optional, Tuple

import pandas as pd
from func_timeout import FunctionTimedOut, func_timeout
from loguru import logger

from .base import AdapterCapability, BaseDataAdapter
from .types import (
    Asset,
    AssetPrice,
    AssetSearchQuery,
    AssetSearchResult,
    AssetType,
    DataSource,
    Exchange,
    Interval,
    LocalizedName,
    MarketInfo,
    MarketStatus,
)

try:
    import baostock as bs
except ImportError:
    bs = None

# Global lock for BaoStock API calls (baostock uses global session state)
_baostock_lock = threading.Lock()


# BaoStock type mapping: 1=Stock, 2=Index, 3=Other, 4=Convertible, 5=ETF
BAOSTOCK_TYPE_STOCK = "1"
BAOSTOCK_TYPE_INDEX = "2"
BAOSTOCK_TYPE_OTHER = "3"
BAOSTOCK_TYPE_CONVERTIBLE = "4"
BAOSTOCK_TYPE_ETF = "5"

# BaoStock code length for symbols like "sh.600000" or "sz.000001"
BAOSTOCK_CODE_LENGTH = 9  # "sh.600000" is 9 characters


class BaoStockAdapter(BaseDataAdapter):
    """Baostock data adapter implementation, only supports SSE and SZSE."""

    def __init__(self, **kwargs):
        """Initialize BaoStock adapter.

        Args:
            **kwargs: Additional configuration parameters
        """
        super().__init__(DataSource.BAOSTOCK, **kwargs)

        if bs is None:
            raise ImportError("baostock library is not installed.")

    def _initialize(self) -> None:
        """Initialize BaoStock adapter configuration."""

        self.timeout = self.config.get("timeout", 10)

        self.exchange_mapping = {
            Exchange.SSE: "sh",
            Exchange.SZSE: "sz",
        }

        self.interval_mapping = {
            f"5{Interval.MINUTE.value}": "5",
            f"15{Interval.MINUTE.value}": "15",
            f"30{Interval.MINUTE.value}": "30",
            f"60{Interval.MINUTE.value}": "60",
            f"1{Interval.DAY.value}": "d",
            f"1{Interval.WEEK.value}": "w",
            f"1{Interval.MONTH.value}": "m",
        }

    def validate_ticker(self, ticker: str) -> bool:
        """Validate if ticker is supported by BaoStock.

        Args:
            ticker: Ticker in internal format (e.g., "SSE:600000", "SZSE:000001")

        Returns:
            True if ticker is supported by BaoStock
        """
        if ":" not in ticker:
            return False

        result = self._get_exchange_and_ticker_code(ticker)
        if result is None:
            return False

        exchange, baostock_code = result

        # Validate exchange is supported
        if exchange not in self.get_supported_exchanges():
            return False

        # Validate baostock code format (e.g., "sh.600000" should be 9 chars)
        if len(baostock_code) != BAOSTOCK_CODE_LENGTH:
            return False

        return True

    def get_real_time_price(self, ticker: str) -> Optional[AssetPrice]:
        """Get real-time price data for an asset from BaoStock.

        Note: BaoStock doesn't have true real-time API. This method fetches
        the most recent daily price data as "current" price (similar to yfinance).

        Args:
            ticker: Asset ticker in internal format (e.g., "SSE:600000")

        Returns:
            AssetPrice object with most recent price or None if not available
        """
        result = self._get_exchange_and_ticker_code(ticker)
        if result is None:
            return None
        _, baostock_code = result

        is_index = self._is_index_code(baostock_code)

        # Fetch most recent daily data (last 5 trading days to ensure we get data)
        end_date = datetime.now()
        start_date = end_date - timedelta(days=10)

        # Use appropriate fields based on asset type
        fields = "date,code,open,high,low,close,volume,preclose,pctChg"

        try:
            rs = self._baostock_api_call_wrapper(
                lambda: bs.query_history_k_data_plus(
                    code=baostock_code,
                    fields=fields,
                    start_date=start_date.strftime("%Y-%m-%d"),
                    end_date=end_date.strftime("%Y-%m-%d"),
                    frequency="d",
                    adjustflag="2" if not is_index else "3",
                )
            )
            if rs is None or rs.error_code != "0":
                logger.warning(
                    "BaoStock real-time price query failed for {ticker}: {msg}",
                    ticker=ticker,
                    msg=rs.error_msg if rs else "No response",
                )