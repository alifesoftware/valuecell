import { useEffect, useRef, useState } from "react";

interface DataNode {
  id: string;
  name: string;
  type: "source" | "adapter" | "api" | "frontend";
  connections: string[];
  color: string;
}

interface ConnectionLinesProps {
  nodes: DataNode[];
  hoveredNode: string | null;
  selectedNode: string | null;
  getConnectedNodes: (nodeId: string) => Set<string>;
}

interface Connection {
  from: string;
  to: string;
  fromColor: string;
  toColor: string;
  isActive: boolean;
}

export default function ConnectionLines({
  nodes,
  hoveredNode,
  selectedNode,
  getConnectedNodes,
}: ConnectionLinesProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const updateConnections = () => {
      const newConnections: Connection[] = [];
      const activeNode = selectedNode || hoveredNode;
      const connectedIds = activeNode ? getConnectedNodes(activeNode) : new Set<string>();

      nodes.forEach((node) => {
        node.connections.forEach((targetId) => {
          const fromElement = document.getElementById(`node-${node.id}`);
          const toElement = document.getElementById(`node-${targetId}`);

          if (fromElement && toElement) {
            const isActive =
              activeNode === node.id ||
              activeNode === targetId ||
              (activeNode && (connectedIds.has(node.id) || connectedIds.has(targetId)));

            newConnections.push({
              from: node.id,
              to: targetId,
              fromColor: node.color,
              toColor: nodes.find((n) => n.id === targetId)?.color || node.color,
              isActive: isActive || false,
            });
          }
        });
      });

      setConnections(newConnections);
    };

    const updateDimensions = () => {
      if (svgRef.current) {
        const rect = svgRef.current.getBoundingClientRect();
        setDimensions({ width: rect.width, height: rect.height });
      }
    };

    updateConnections();
    updateDimensions();

    window.addEventListener("resize", updateDimensions);
    window.addEventListener("scroll", updateConnections);

    // Update on layout changes
    const observer = new MutationObserver(updateConnections);
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
    });

    return () => {
      window.removeEventListener("resize", updateDimensions);
      window.removeEventListener("scroll", updateConnections);
      observer.disconnect();
    };
  }, [nodes, hoveredNode, selectedNode, getConnectedNodes]);

  const getPath = (fromId: string, toId: string): string => {
    const fromElement = document.getElementById(`node-${fromId}`);
    const toElement = document.getElementById(`node-${toId}`);

    if (!fromElement || !toElement || !svgRef.current) return "";

    const svgRect = svgRef.current.getBoundingClientRect();
    const fromRect = fromElement.getBoundingClientRect();
    const toRect = toElement.getBoundingClientRect();

    const startX = fromRect.left + fromRect.width / 2 - svgRect.left;
    const startY = fromRect.bottom - svgRect.top;
    const endX = toRect.left + toRect.width / 2 - svgRect.left;
    const endY = toRect.top - svgRect.top;

    const midY = (startY + endY) / 2;

    return `M ${startX} ${startY} C ${startX} ${midY}, ${endX} ${midY}, ${endX} ${endY}`;
  };

  return (
    <svg
      ref={svgRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ width: "100%", height: "100%" }}
    >
      <defs>
        {connections.map((conn, idx) => (
          <linearGradient
            key={`gradient-${idx}`}
            id={`gradient-${conn.from}-${conn.to}`}
            x1="0%"
            y1="0%"
            x2="0%"
            y2="100%"
          >
            <stop offset="0%" stopColor={conn.fromColor} stopOpacity={conn.isActive ? 0.6 : 0.2} />
            <stop offset="100%" stopColor={conn.toColor} stopOpacity={conn.isActive ? 0.6 : 0.2} />
          </linearGradient>
        ))}

        {/* Animated gradient for active connections */}
        <linearGradient id="pulse-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="oklch(0.55 0.18 264)" stopOpacity="0.8">
            <animate
              attributeName="stop-opacity"
              values="0.2;0.8;0.2"
              dur="2s"
              repeatCount="indefinite"
            />
          </stop>
          <stop offset="50%" stopColor="oklch(0.65 0.15 45)" stopOpacity="0.6">
            <animate
              attributeName="stop-opacity"
              values="0.1;0.6;0.1"
              dur="2s"
              repeatCount="indefinite"
            />
          </stop>
          <stop offset="100%" stopColor="oklch(0.55 0.16 160)" stopOpacity="0.8">
            <animate
              attributeName="stop-opacity"
              values="0.2;0.8;0.2"
              dur="2s"
              repeatCount="indefinite"
            />
          </stop>
        </linearGradient>
      </defs>

      {connections.map((conn, idx) => {
        const path = getPath(conn.from, conn.to);
        if (!path) return null;

        return (
          <g key={`connection-${idx}`}>
            {/* Background line */}
            <path
              d={path}
              fill="none"
              stroke={`url(#gradient-${conn.from}-${conn.to})`}
              strokeWidth={conn.isActive ? 3 : 1.5}
              strokeLinecap="round"
              className="transition-all duration-300"
              opacity={conn.isActive ? 1 : 0.3}
            />

            {/* Animated pulse for active connections */}
            {conn.isActive && (
              <>
                <path
                  d={path}
                  fill="none"
                  stroke="url(#pulse-gradient)"
                  strokeWidth={5}
                  strokeLinecap="round"
                  opacity={0.4}
                  className="animate-pulse"
                />

                {/* Animated dot traveling along the path */}
                <circle r="4" fill={conn.toColor} opacity={0.8}>
                  <animateMotion dur="3s" repeatCount="indefinite" path={path} />
                  <animate
                    attributeName="opacity"
                    values="0;0.8;0.8;0"
                    dur="3s"
                    repeatCount="indefinite"
                  />
                </circle>
              </>
            )}
          </g>
        );
      })}
    </svg>
  );
}
