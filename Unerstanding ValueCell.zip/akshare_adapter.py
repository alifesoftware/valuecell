
This adapter provides integration with AKShare library to fetch comprehensive
Global financial market data including stocks, funds, bonds, and economic indicators.
"""

import logging
import os
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, Dict, List, Optional

import pandas as pd

try:
    import akshare as ak
except ImportError:
    ak = None

from .base import AdapterCapability, BaseDataAdapter
from .types import (
    Asset,
    AssetPrice,
    AssetSearchQuery,
    AssetSearchResult,
    AssetType,
    DataSource,
    Exchange,
    Interval,
    LocalizedName,
    MarketInfo,
    MarketStatus,
)

logger = logging.getLogger(__name__)


class AKShareAdapter(BaseDataAdapter):
    """AKShare data adapter for Chinese financial markets."""

    def __init__(self, **kwargs):
        """Initialize AKShare adapter.

        Args:
            **kwargs: Additional configuration parameters
        """
        super().__init__(DataSource.AKSHARE, **kwargs)

        if ak is None:
            raise ImportError(
                "akshare library is required. Install with: pip install akshare"
            )

    def _initialize(self) -> None:
        """Initialize AKShare adapter configuration."""
        self.timeout = self.config.get("timeout", 10)  # Reduced timeout duration

        # Field mapping - Handle AKShare API field changes
        self.field_mappings = {
            "a_shares": {
                "code": ["代码", "symbol", "ts_code"],
                "name": ["名称", "name", "short_name"],
                "price": ["最新价", "close", "price", "latest"],
                "open": ["今开", "开盘", "open"],
                "high": ["最高", "high"],
                "low": ["最低", "low"],
                "close": ["收盘", "close", "latest"],
                "volume": ["成交量", "volume", "vol"],
                "market_cap": ["总市值", "total_mv"],
                "change": ["涨跌额", "change"],
                "change_percent": ["涨跌幅", "change_percent", "pct_chg"],
                "date": ["日期", "date", "trade_date"],
                "time": ["时间", "time", "datetime"],
            },
            "hk_stocks": {
                "code": ["symbol", "code", "代码"],
                "name": ["name", "名称", "short_name"],
                "price": ["最新价", "close", "latest"],
                "open": ["开盘", "open"],
                "high": ["最高", "high"],
                "low": ["最低", "low"],
                "close": ["收盘", "close", "latest"],
                "volume": ["成交量", "volume", "vol"],
                "change": ["涨跌额", "change"],
                "change_percent": ["涨跌幅", "change_percent", "pct_chg"],
                "date": ["日期", "date", "trade_date"],
                "time": ["时间", "time", "datetime"],
            },
            "us_stocks": {
                "code": ["代码", "symbol", "ticker"],
                "name": ["名称", "name", "short_name"],
                "price": ["最新价", "close", "price", "latest"],
                "open": ["开盘", "open"],
                "high": ["最高", "high"],
                "low": ["最低", "low"],
                "close": ["收盘", "close", "latest"],
                "volume": ["成交量", "volume", "vol"],
                "change": ["涨跌额", "change"],
                "change_percent": ["涨跌幅", "change_percent", "pct_chg"],
                "date": ["日期", "date", "trade_date"],
                "time": ["时间", "time", "datetime"],
            },
        }

        # Exchange mapping for AKShare
        self.exchange_mapping = {
            "SH": Exchange.SSE.value,  # Shanghai Stock Exchange
            "SZ": Exchange.SZSE.value,  # Shenzhen Stock Exchange
            "BJ": Exchange.BSE.value,  # Beijing Stock Exchange
            "HK": Exchange.HKEX.value,  # Hong Kong Stock Exchange
            "NYSE": Exchange.NYSE.value,  # New York Stock Exchange
            "NASDAQ": Exchange.NASDAQ.value,  # NASDAQ Exchange
            "AMEX": Exchange.AMEX.value,  # AMEX Exchange
        }

        # US exchange codes for AKShare API
        # AKShare requires exchange code prefix for US stocks and indices
        # Format: exchange_code.SYMBOL (e.g., 105.AAPL for NASDAQ:AAPL, 100.IXIC for INDEX)
        # Code 100: US Index data (for INDEX asset type)
        # Code 105: NASDAQ stocks
        # Code 106: NYSE stocks
        # Code 107: AMEX stocks
        self.us_exchange_codes = {
            Exchange.NASDAQ: "105",
            Exchange.NYSE: "106",
            Exchange.AMEX: "107",
        }

        # Special exchange code for US indices
        self.us_index_exchange_code = "100"

        # Reverse mapping for converting AKShare format back to internal format
        self.us_exchange_codes_reverse = {
            v: k for k, v in self.us_exchange_codes.items()
        }
        # Add index code to reverse mapping
        self.us_exchange_codes_reverse["100"] = None  # Special handling for indices

        logger.info("AKShare adapter initialized with caching and field mapping")

    def _get_market_type(self, exchange: Exchange) -> str:
        """Get market type identifier for field mapping.

        Args:
            exchange: Exchange enum

        Returns:
            Market type string ('a_shares', 'hk_stocks', or 'us_stocks')
        """
        if exchange in [Exchange.SSE, Exchange.SZSE, Exchange.BSE]:
            return "a_shares"
        elif exchange == Exchange.HKEX:
            return "hk_stocks"
        elif exchange in [Exchange.NASDAQ, Exchange.NYSE, Exchange.AMEX]:
            return "us_stocks"
        else:
            return "a_shares"  # Default fallback

    def _get_currency(self, exchange: Exchange) -> str:
        """Get currency code based on exchange.

        Args:
            exchange: Exchange enum

        Returns:
            Currency code (CNY, HKD, or USD)
        """
        if exchange in [Exchange.SSE, Exchange.SZSE, Exchange.BSE]:
            return "CNY"
        elif exchange == Exchange.HKEX:
            return "HKD"
        elif exchange in [Exchange.NASDAQ, Exchange.NYSE, Exchange.AMEX]:
            return "USD"
        else:
            return "USD"  # Default fallback

    def _is_hk_index(self, ticker: str) -> bool:
        """Check if a ticker is a Hong Kong index.

        Args:
            ticker: Asset ticker in internal format

        Returns:
            True if ticker is a HK index, False otherwise
        """
        try:
            # Check database first
            from ...server.db.repositories.asset_repository import (
                get_asset_repository,
            )

            asset_repo = get_asset_repository()
            asset = asset_repo.get_asset_by_symbol(ticker)

            if asset and asset.asset_type == AssetType.INDEX.value:
                exchange_str = ticker.split(":")[0] if ":" in ticker else ""
                return exchange_str == Exchange.HKEX.value
        except (ImportError, Exception) as e:
            logger.debug(f"Could not check asset type from database: {e}")
