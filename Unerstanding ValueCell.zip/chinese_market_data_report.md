# ValueCell Integration Report: Chinese Market Data

This report details the integration of Chinese financial market data within the ValueCell application. The primary sources for this data are the **AKShare** and **BaoStock** libraries, each accessed through a dedicated adapter.

## 1. Overview of Adapters

ValueCell employs two specialized adapters to handle data from the Chinese markets, providing comprehensive coverage and redundancy:

-   **`AKShareAdapter`**: Located at `python/valuecell/adapters/assets/akshare_adapter.py`, this adapter uses the `akshare` library to fetch a wide array of data, including real-time and historical prices for stocks, funds, and more.
-   **`BaoStockAdapter`**: Found in `python/valuecell/adapters/assets/baostock_adapter.py`, this adapter utilizes the `baostock` library, which is known for providing free, high-quality historical A-share data.

## 2. AKShare Adapter (`akshare_adapter.py`)

The `AKShareAdapter` is a versatile tool for accessing data from mainland China and Hong Kong markets.

### Key Features:

-   **Broad Market Coverage**: Supports Shanghai (SSE), Shenzhen (SZSE), Beijing (BSE), and Hong Kong (HKEX) stock exchanges.
-   **Data Normalization**: Implements extensive field mappings to create a consistent data structure from the varied formats provided by `akshare` for different markets (A-shares, HK stocks, US stocks).
-   **Intelligent Search**: Provides asset search functionality that can query for stocks across the supported exchanges.
-   **Comprehensive Data Retrieval**: Includes methods to get detailed asset information, real-time quotes, and historical OHLCV (Open, High, Low, Close, Volume) data.

### Core Methods:

| Method                  | Description                                                                 |
| :---------------------- | :-------------------------------------------------------------------------- |
| `search_assets`         | Searches for assets using the `akshare` library.                            |
| `get_asset_info`        | Retrieves detailed information for a specific stock ticker.               |
| `get_real_time_price`   | Fetches the latest available price for an asset.                            |
| `get_historical_prices` | Gathers historical price data for a given ticker, interval, and date range. |

## 3. BaoStock Adapter (`baostock_adapter.py`)

The `BaoStockAdapter` serves as a specialized and reliable source for historical A-share data.

### Key Features:

-   **Focused Coverage**: Primarily targets the Shanghai (SSE) and Shenzhen (SZSE) exchanges.
-   **Authenticated Access**: Manages login sessions with the BaoStock service, which is a prerequisite for data access.
-   **Robust API Interaction**: Uses a wrapper function (`_baostock_api_call_wrapper`) to handle API calls, including timeouts and the global login state required by the library.
-   **Ticker and Interval Mapping**: Translates ValueCell's internal ticker and interval formats (e.g., `SSE:600000`, `5m`) to the formats required by BaoStock (e.g., `sh.600000`, `5`).

### Core Methods:

| Method                  | Description                                                                                              |
| :---------------------- | :------------------------------------------------------------------------------------------------------- |
| `get_real_time_price`   | Simulates real-time price fetching by retrieving the most recent daily data, as BaoStock lacks a true real-time feed. |
| `get_historical_prices` | Fetches historical daily or intraday K-line (OHLCV) data.                                                |
| `search_assets`         | Searches for stocks and indices within the SSE and SZSE markets.                                         |

## 4. CNINFO for Official Filings

In addition to market data, ValueCell directly accesses the **CNINFO** website (`http://www.cninfo.com.cn`), the designated disclosure platform for listed companies in China. This is handled in `python/valuecell/agents/research_agent/sources.py`.

-   **Direct HTTP Requests**: The application makes POST requests to CNINFO's API endpoints to search for companies and query for historical announcements and filings.
-   **PDF Document Retrieval**: It constructs URLs to download official PDF documents (e.g., annual reports, quarterly reports) directly from `http://static.cninfo.com.cn/`.

## 5. Conclusion

ValueCell's approach to Chinese market data is multi-layered and robust. By combining the broad capabilities of **AKShare**, the reliable historical data from **BaoStock**, and official filings from **CNINFO**, the platform ensures comprehensive and accurate data coverage for users interested in Chinese equities. The use of dedicated adapters encapsulates the complexity of each source, presenting a unified interface to the rest of the application.
