
This adapter provides integration with Yahoo Finance API through the yfinance library
to fetch stock market data, including real-time prices and historical data.
"""

import logging
import time
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional

import yfinance as yf

from .base import AdapterCapability, BaseDataAdapter
from .types import (
    Asset,
    AssetPrice,
    AssetSearchQuery,
    AssetSearchResult,
    AssetType,
    DataSource,
    Exchange,
    Interval,
    LocalizedName,
    MarketInfo,
    MarketStatus,
)

logger = logging.getLogger(__name__)


class YFinanceAdapter(BaseDataAdapter):
    """Yahoo Finance data adapter implementation."""

    def __init__(self, **kwargs):
        """Initialize Yahoo Finance adapter."""
        super().__init__(DataSource.YFINANCE, **kwargs)

        if yf is None:
            raise ImportError(
                "yfinance library is required. Install with: pip install yfinance"
            )

    def _initialize(self) -> None:
        """Initialize Yahoo Finance adapter configuration."""
        self.timeout = self.config.get("timeout", 30)
        self.retry_attempts = int(self.config.get("retry_attempts", 3))
        self.retry_backoff_base = float(self.config.get("retry_backoff_base", 0.5))

        # Asset type mapping for Yahoo Finance
        self.quote_type_to_asset_type_mapping = {
            "EQUITY": AssetType.STOCK,
            "ETF": AssetType.ETF,
            "INDEX": AssetType.INDEX,
            "CRYPTOCURRENCY": AssetType.CRYPTO,
        }

        # Map yfinance exchanges to our internal exchanges
        self.exchange_mapping = {
            "NMS": Exchange.NASDAQ,
            "NYQ": Exchange.NYSE,
            "ASE": Exchange.AMEX,
            "SHH": Exchange.SSE,
            "SHZ": Exchange.SZSE,
            "HKG": Exchange.HKEX,
            "PCX": Exchange.NYSE,
            "CCC": Exchange.CRYPTO,
        }

        self.yfinance_exchange_suffix_mapping = {
            Exchange.NASDAQ.value: "",
            Exchange.NYSE.value: "",
            Exchange.AMEX.value: "",
            Exchange.SSE.value: ".SS",
            Exchange.SZSE.value: ".SZ",
            Exchange.HKEX.value: ".HK",
            Exchange.CRYPTO.value: "-USD",
        }

        logger.info("Yahoo Finance adapter initialized")

    def search_assets(self, query: AssetSearchQuery) -> List[AssetSearchResult]:
        """Search for assets using Yahoo Finance Search API.

        Uses yfinance.Search for better search results across stocks, ETFs, and other assets.
        Falls back to direct ticker lookup for specific symbols.

        This method
        """
        results = []
        search_term = query.query.strip()

        try:
            # Use yfinance Search API for comprehensive search
            search_obj = yf.Search(search_term)

            # Get search results from different categories
            search_quotes = getattr(search_obj, "quotes", [])

            # Process search results
            for quote in search_quotes:
                try:
                    result = self._create_search_result_from_quote(quote)
                    if result:
                        results.append(result)
                except Exception as e:
                    logger.debug(f"Error processing search quote: {e}")
                    continue

        except Exception as e:
            logger.error(f"yfinance Search API failed for '{search_term}': {e}")

        return results[: query.limit]

    def _create_search_result_from_quote(
        self, quote: Dict
    ) -> Optional[AssetSearchResult]:
        """Create search result from Yahoo Finance search quote."""
        try:
            symbol = quote.get("symbol", "")
            if not symbol:
                return None

            # Get exchange information first
            exchange = quote.get("exchange")
            if not exchange:
                return None

            mapped_exchange = self.exchange_mapping.get(exchange)

            # Filter: Only support specific exchanges
            if mapped_exchange not in self.exchange_mapping.values():
                logger.debug(
                    f"Skipping unsupported exchange: {mapped_exchange} for symbol {symbol}"
                )
                return None

            # Convert to internal ticker format and normalize
            # Remove any suffixes that yfinance might include
            internal_ticker = self.convert_to_internal_ticker(
                symbol, mapped_exchange.value
            )

            # Validate the ticker format
            if not self.validate_ticker(internal_ticker):
                logger.debug(
                    f"Invalid ticker format after conversion: {internal_ticker}"
                )
                return None

            # Get asset type from quote type
            quote_type = quote.get("quoteType", "").upper()
            asset_type = self.quote_type_to_asset_type_mapping.get(
                quote_type, AssetType.STOCK
            )

            # Get country information
            country = "US"  # Default
            if mapped_exchange in [Exchange.SSE, Exchange.SZSE]:
                country = "CN"
            elif mapped_exchange == Exchange.HKEX:
                country = "HK"
            elif mapped_exchange == Exchange.CRYPTO:
                country = "US"

            # Get names in different languages
            long_name = quote.get("longname", quote.get("shortname", symbol))
            short_name = quote.get("shortname", symbol)

            names = {
                "en-US": long_name or short_name,
                "en-GB": long_name or short_name,
            }

            # Create search result
            search_result = AssetSearchResult(
                ticker=internal_ticker,
                asset_type=asset_type,
                names=names,
                exchange=mapped_exchange.value,
                country=country,
                currency=quote.get("currency", "USD"),
                market_status=MarketStatus.UNKNOWN,
            )

            # Save asset metadata to database for future lookups
            try:
                from ...server.db.repositories.asset_repository import (
                    get_asset_repository,
                )

                asset_repo = get_asset_repository()
                asset_repo.upsert_asset(
                    symbol=internal_ticker,
                    name=long_name or short_name,
                    asset_type=asset_type.value,
                    description=quote.get("longname"),
                    sector=quote.get("sector"),
                    asset_metadata={
                        "currency": quote.get("currency", "USD"),
                        "exchange_code": exchange,  # Original yfinance exchange code
                        "quote_type": quote_type,
                    },
                )
                logger.debug(f"Saved asset metadata for {internal_ticker}")
            except Exception as e:
                # Don't fail the search if database save fails
                logger.warning(
                    f"Failed to save asset metadata for {internal_ticker}: {e}"
                )

            return search_result

        except Exception as e:
            logger.error(f"Error creating search result from quote: {e}")
            return None

    def get_asset_info(self, ticker: str) -> Optional[Asset]:
        """Get detailed asset information from Yahoo Finance."""
        try:
            source_ticker = self.convert_to_source_ticker(ticker)

            info = None
            for attempt in range(max(1, self.retry_attempts)):
                try:
                    ticker_obj = yf.Ticker(source_ticker)
                    try:
                        info = ticker_obj.info
                    except Exception:
                        try:
                            info = ticker_obj.get_info()
                        except Exception:
                            info = None
                    if info and "symbol" in info:
                        break
                except Exception as e:
                    if attempt < self.retry_attempts - 1:
                        time.sleep(self.retry_backoff_base * (2**attempt))
                        continue
                    logger.error(f"Error fetching asset info for {ticker}: {e}")
                    return None

            if not info or "symbol" not in info:
                try:
                    search_obj = yf.Search(source_ticker)
                    quotes = getattr(search_obj, "quotes", []) or []
                    chosen = None
                    for q in quotes:
                        if q.get("symbol") == source_ticker:
                            chosen = q
                            break
                    if not chosen and quotes:
                        chosen = quotes[0]

                    if chosen:
                        names = LocalizedName()
                        long_name = chosen.get("longname") or chosen.get(
                            "shortname", ticker
                        )
                        names.set_name("en-US", long_name)

                        mapped_exchange = self.exchange_mapping.get(
                            chosen.get("exchange")
                        )
                        market_info = MarketInfo(
                            exchange=mapped_exchange.value
                            if mapped_exchange
                            else "UNKNOWN",
                            country="US",
                            currency=chosen.get("currency", "USD"),
                            timezone=chosen.get(
                                "exchangeTimezoneName", "America/New_York"
                            ),
                        )

                        asset_type = self.quote_type_to_asset_type_mapping.get(
                            str(chosen.get("quoteType", "")).upper(), AssetType.STOCK
                        )

                        asset = Asset(
                            ticker=ticker,
                            asset_type=asset_type,
                            names=names,
                            market_info=market_info,
                        )
                        asset.set_source_ticker(self.source, source_ticker)
                        return asset
                except Exception:
                    pass

                try:
                    ticker_obj = yf.Ticker(source_ticker)
                    fast_info = getattr(ticker_obj, "fast_info", None)
                    fi = fast_info if isinstance(fast_info, dict) else None
                    names = LocalizedName()
                    names.set_name("en-US", ticker)
                    market_info = MarketInfo(
                        exchange=ticker.split(":")[0] if ":" in ticker else "UNKNOWN",
                        country="US",
                        currency=(fi or {}).get("currency", "USD"),
                        timezone="America/New_York",
                    )
                    asset = Asset(
                        ticker=ticker,
                        asset_type=AssetType.STOCK,
                        names=names,
                        market_info=market_info,
                    )
                    asset.set_source_ticker(self.source, source_ticker)
                    return asset
                except Exception:
                    return None

            # Create localized names
            names = LocalizedName()
            long_name = info.get("longName", info.get("shortName", ticker))
            names.set_name("en-US", long_name)

            exchange = None
            if info.get("exchange"):
                exchange = self.exchange_mapping.get(info.get("exchange"))

            # Create market info
            market_info = MarketInfo(
                exchange=exchange.value if exchange else "UNKNOWN",
                country=info.get("country", "US"),
                currency=info.get("currency", "USD"),
                timezone=info.get("exchangeTimezoneName", "America/New_York"),
            )

            # Determine asset type
            asset_type = self.quote_type_to_asset_type_mapping.get(
                info.get("quoteType", "").upper(), AssetType.STOCK
            )

            # Create asset object
            asset = Asset(
                ticker=ticker,
                asset_type=asset_type,
                names=names,
                market_info=market_info,
            )

            # Set source mapping
            asset.set_source_ticker(self.source, source_ticker)

            # Add additional properties
            properties = {
                "sector": info.get("sector"),
                "industry": info.get("industry"),
                "market_cap": info.get("marketCap"),
                "pe_ratio": info.get("trailingPE"),
                "dividend_yield": info.get("dividendYield"),
                "beta": info.get("beta"),
                "website": info.get("website"),
                "business_summary": info.get("longBusinessSummary"),
            }

            # Filter out None values
            properties = {k: v for k, v in properties.items() if v is not None}
            asset.properties.update(properties)

            # Save asset metadata to database
            try:
                from ...server.db.repositories.asset_repository import (
                    get_asset_repository,
                )

                asset_repo = get_asset_repository()
                asset_repo.upsert_asset(
                    symbol=ticker,
                    name=long_name,
                    asset_type=asset_type.value,
                    description=info.get("longBusinessSummary"),
                    sector=info.get("sector"),
                    asset_metadata={
                        "currency": info.get("currency", "USD"),
                        "exchange_code": info.get("exchange"),
                        "quote_type": info.get("quoteType"),
                        "industry": info.get("industry"),
                        "market_cap": info.get("marketCap"),
                    },
                )
                logger.debug(f"Saved asset info for {ticker}")
            except Exception as e:
                # Don't fail the info fetch if database save fails
                logger.warning(f"Failed to save asset info for {ticker}: {e}")

            return asset

        except Exception as e:
            logger.error(f"Error fetching asset info for {ticker}: {e}")
            return None

    def get_real_time_price(self, ticker: str) -> Optional[AssetPrice]:
        """Get real-time price data from Yahoo Finance."""
        try:
            source_ticker = self.convert_to_source_ticker(ticker)
            ticker_obj = yf.Ticker(source_ticker)

            # Get current data
            data = None
            try:
                data = ticker_obj.history(period="1d", interval="1m")
            except Exception:
                data = None
            if data is None or data.empty:
                try:
                    fast_info = getattr(ticker_obj, "fast_info", None)
                    fi = fast_info if isinstance(fast_info, dict) else None
                    if fi is None:
                        try:
                            fi = ticker_obj.get_fast_info()
                        except Exception:
                            fi = None
                    price_val = None
                    if fi:
                        price_val = (
                            fi.get("last_price")
                            or fi.get("regular_market_price")
                            or fi.get("last_close")
                        )
                    if price_val is None:
                        return None
                    current_price = Decimal(str(price_val))
                    prev_close_val = None
                    if fi and fi.get("previous_close") is not None:
                        prev_close_val = Decimal(str(fi.get("previous_close")))
                    else:
                        prev_close_val = current_price
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)