# ValueCell Integration Report: Cryptocurrency Data

This report provides an in-depth analysis of how the ValueCell application integrates and processes data from the cryptocurrency markets. The platform employs a sophisticated, multi-pronged strategy that combines real-time exchange data, trading execution, and detailed project information scraped from the web.

## 1. Overview of Cryptocurrency Data Sources

ValueCell utilizes several key components to deliver comprehensive cryptocurrency data and trading capabilities:

-   **CCXT (CryptoCurrency eXchange Trading Library)**: Serves as the core engine for connecting to and interacting with a wide range of cryptocurrency exchanges. It is used for both data retrieval and trade execution.
-   **RootData**: A web scraping module that uses Playwright to extract detailed, qualitative data about cryptocurrency projects from the `rootdata.com` website.
-   **Exchange-Specific Configurations**: A metadata system defines the specific requirements for each supported exchange, such as API key formats and authentication methods.

## 2. CCXT for Exchange Integration and Trading

The central component for all exchange-related activities is the `CCXTExecutionGateway`, located at `python/valuecell/agents/common/trading/execution/ccxt_trading.py`. This class provides a unified interface for interacting with numerous exchanges.

### Key Features:

-   **Unified API**: Abstracts the differences between various exchange APIs, allowing the application to use a consistent method for placing orders, fetching balances, and retrieving market data.
-   **Support for Multiple Exchanges**: The code is structured to support exchanges like **Binance, OKX, Hyperliquid, Coinbase, Gate.io, and MEXC**.
-   **Authentication Handling**: Manages different authentication schemes, including standard API key/secret pairs, passphrases (for OKX and Coinbase), and wallet-based authentication (for Hyperliquid).
-   **Market and Order Normalization**: It normalizes trading pair symbols (e.g., converting `BTC-USDT` to the `BTC/USDT:USDT` format required by some exchanges for futures) and handles different order types (spot, futures, swaps).
-   **Real-Time Data with CCXT Pro**: The use of `ccxt.pro` in `python/valuecell/agents/common/trading/utils.py` indicates that the application leverages WebSockets for receiving real-time market data, such as order book updates and live trades, without the need for constant polling.

### Core Methods:

| Method                | Description                                                                                             |
| :-------------------- | :------------------------------------------------------------------------------------------------------ |
| `execute`             | The main method for executing a `TradeInstruction`, handling logic for opening/closing long/short positions. |
| `fetch_balance`       | Retrieves the user's account balance from the exchange.                                                 |
| `fetch_positions`     | Fetches the user's current open positions on the exchange.                                              |
| `test_connection`     | Verifies that the provided API credentials are valid and that a connection can be established.          |
| `_get_exchange`       | A lazy-initializer that creates and configures the CCXT exchange instance on first use.                 |

## 3. RootData for Project Intelligence

While CCXT provides quantitative market data, ValueCell enriches this with qualitative data scraped from `https://www.rootdata.com` using a dedicated module in `python/valuecell/agents/sources/rootdata.py`.

### Key Features:

-   **Web Scraping with Playwright**: It uses browser automation to visit project pages on RootData and extracts detailed information directly from the page's JavaScript objects (`window.__NUXT__`), which is a common technique for scraping server-side rendered (SSR) web applications.
-   **Rich Data Extraction**: This method allows ValueCell to gather over 40 distinct data fields for a project, including:
    -   **Fundamental Data**: Project descriptions, founding year, tags, and associated blockchain ecosystems.
    -   **Tokenomics**: Circulating supply, total supply, and max supply.
    -   **Social and Community Metrics**: Links to social media, community sentiment, and holder statistics.
    -   **VC and Funding**: Information about venture capital investors and funding rounds.

## 4. Exchange Configuration

The file `python/valuecell/agents/common/trading/execution/exchanges.py` contains metadata for each supported exchange. This centralized configuration defines the specific authentication requirements for each platform, making it easy to add new exchanges or modify existing ones.

| Exchange         | API Key | Secret | Passphrase | Special Auth         |
| :--------------- | :------ | :----- | :--------- | :------------------- |
| **Binance**      | Yes     | Yes    | No         | None                 |
| **OKX**          | Yes     | Yes    | Yes        | None                 |
| **Hyperliquid**  | No      | No     | No         | `privateKey`, `walletAddress` |
| **Coinbase**     | Yes     | Yes    | Yes        | None                 |
| **Gate.io**      | Yes     | Yes    | No         | None                 |
| **MEXC**         | Yes     | Yes    | No         | None                 |

## 5. Conclusion

ValueCell's cryptocurrency data integration is both powerful and flexible. It combines the real-time trading and market data capabilities of the **CCXT** library with deep, qualitative project intelligence from **RootData**. This dual approach allows the platform to provide users not only with the tools to trade effectively but also with the in-depth information needed to make informed investment decisions. The modular design, centered around the `CCXTExecutionGateway` and specialized data source modules, creates a scalable and maintainable architecture.
