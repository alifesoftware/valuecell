import os
import random
from typing import Dict, List, Optional, Tuple

import ccxt.pro as ccxtpro
import httpx
from loguru import logger

from valuecell.agents.common.trading.constants import (
    FEATURE_GROUP_BY_KEY,
    FEATURE_GROUP_BY_MARKET_SNAPSHOT,
)
from valuecell.agents.common.trading.models import (
    FeatureVector,
    InstrumentRef,
    PositionSnapshot,
    TradeType,
)


async def fetch_free_cash_from_gateway(
    execution_gateway, symbols: list[str], retry_cnt: int = 0, max_retries: int = 3
) -> Tuple[float, float]:
    """Fetch exchange balance via `execution_gateway.fetch_balance()` and
    aggregate free cash for the given `symbols` (quote currencies).

    Returns aggregated free cash as float. Returns 0.0 on error or when
    balance shape cannot be parsed.
    """
    logger.info("Fetching exchange balance for LIVE trading mode")
    try:
        if not hasattr(execution_gateway, "fetch_balance"):
            raise AttributeError(
                f"Execution gateway {execution_gateway.__class__.__name__} "
                "does not implement the required 'fetch_balance' method."
            )
        balance = await execution_gateway.fetch_balance()
    except Exception as e:
        if retry_cnt < max_retries:
            logger.warning(
                f"Failed to fetch free cash from exchange, retrying... ({retry_cnt + 1}/{max_retries})"
            )
            await asyncio.sleep(
                random.uniform(retry_cnt, retry_cnt + 1)
            )  # jitter to prevent mass retry at the same time
            return await fetch_free_cash_from_gateway(
                execution_gateway, symbols, retry_cnt + 1, max_retries
            )
        # Propagate after exhausting retries so upstream can keep cached portfolio
        logger.error(
            f"Failed to fetch free cash from exchange after {max_retries} retries.",
            exception=e,
        )
        raise

    logger.info(f"Raw balance response: {balance}")
    free_map: dict[str, float] = {}
    # ccxt balance may be shaped as: {'free': {...}, 'used': {...}, 'total': {...}}
    try:
        free_section = balance.get("free") if isinstance(balance, dict) else None
    except Exception:
        free_section = None

    if isinstance(free_section, dict):
        free_map = {str(k).upper(): float(v or 0.0) for k, v in free_section.items()}
    else:
        # fallback: per-ccy dicts: balance['USDT'] = {'free': x, 'used': y, 'total': z}
        iterable = balance.items() if isinstance(balance, dict) else []
        for k, v in iterable:
            if isinstance(v, dict) and "free" in v:
                try:
                    free_map[str(k).upper()] = float(v.get("free") or 0.0)
                except Exception:
                    continue

    # If balance structure is unrecognized, avoid returning zeros silently
    if not isinstance(balance, dict) or (not free_map and free_section is None):
        raise ValueError("Unrecognized balance response shape from exchange")

    logger.info(f"Parsed free balance map: {free_map}")
    # Derive quote currencies from symbols, fallback to common USD-stable quotes
    quotes: list[str] = []
    for sym in symbols or []:
        s = str(sym).upper()
        if "/" in s and len(s.split("/")) == 2:
            quotes.append(s.split("/")[1])
        elif "-" in s and len(s.split("-")) == 2:
            quotes.append(s.split("-")[1])

    # Deduplicate preserving order
    quotes = list(dict.fromkeys(quotes))
    logger.info(f"Quote currencies from symbols: {quotes}")

    free_cash = 0.0
    total_cash = 0.0

    # Sum up free and total cash from relevant quote currencies
    if quotes:
        for q in quotes:
            free_cash += float(free_map.get(q, 0.0) or 0.0)
            # Try to find total/equity in balance if available (often 'total' dict in CCXT)
            # Hyperliquid/CCXT structure: balance[q]['total']
            q_data = balance.get(q)
            if isinstance(q_data, dict):
                total_cash += float(q_data.get("total", 0.0) or 0.0)
            else:
                # Fallback if structure is flat or missing
                total_cash += float(free_map.get(q, 0.0) or 0.0)
    else:
        for q in ("USDT", "USD", "USDC"):
            free_cash += float(free_map.get(q, 0.0) or 0.0)
            q_data = balance.get(q)
            if isinstance(q_data, dict):
                total_cash += float(q_data.get("total", 0.0) or 0.0)
            else:
                total_cash += float(free_map.get(q, 0.0) or 0.0)

    logger.debug(
        f"Synced balance from exchange: free_cash={free_cash}, total_cash={total_cash}, quotes={quotes}"
    )

    return float(free_cash), float(total_cash)


async def fetch_positions_from_gateway(
    execution_gateway, retry_cnt: int = 0, max_retries: int = 3
) -> Dict[str, PositionSnapshot]:
    """Fetch positions from exchange."""
    logger.info("Fetching positions for LIVE trading mode")
    try:
        if not hasattr(execution_gateway, "fetch_positions"):
            raise AttributeError(
                f"Execution gateway {execution_gateway.__class__.__name__} "
                "does not implement the required 'fetch_positions' method."
            )
        raw_positions = await execution_gateway.fetch_positions()
    except Exception as e:
        if retry_cnt < max_retries:
            logger.warning(
                f"Failed to fetch positions from exchange, retrying... ({retry_cnt + 1}/{max_retries})"
            )
            await asyncio.sleep(
                random.uniform(retry_cnt, retry_cnt + 1)
            )  # jitter to prevent mass retry at the same time
            return await fetch_positions_from_gateway(
                execution_gateway, retry_cnt + 1, max_retries
            )
        logger.error(
            f"Failed to fetch positions from exchange after {max_retries} retries.",