# ValueCell Backend API Documentation

This document provides a comprehensive reference for the ValueCell backend API, which is hosted at `https://backend.valuecell.ai/api/v1`. The API is built with FastAPI and provides a range of endpoints for managing watchlists, interacting with agents, and retrieving financial data.

## Authentication

Most endpoints do not require authentication in the open-source version. However, some endpoints related to user-specific data may implicitly use a `DEFAULT_USER_ID` for data storage and retrieval.

---

## Watchlist API (`/watchlist`)

This section of the API is dedicated to managing watchlists and retrieving data about financial assets.

### `GET /asset/search`

-   **Description**: Searches for financial assets based on a query string and optional filters.
-   **Query Parameters**:
    -   `q` (string, required): The search term.
    -   `asset_types` (string, optional): A comma-separated list of asset types to filter by (e.g., `STOCK,ETF`).
    -   `exchanges` (string, optional): A comma-separated list of exchange codes to filter by (e.g., `NASDAQ,NYSE`).
    -   `countries` (string, optional): A comma-separated list of country codes (e.g., `US,CN`).
    -   `limit` (integer, optional, default: 50): The maximum number of results to return.
    -   `language` (string, optional): The language for localized results (e.g., `en-US`).
-   **Success Response (200)**: Returns a `SuccessResponse` containing `AssetSearchResultData`, which includes a list of found assets.

### `GET /asset/{ticker}`

-   **Description**: Retrieves detailed information for a single financial asset.
-   **Path Parameter**:
    -   `ticker` (string, required): The asset ticker in the format `EXCHANGE:SYMBOL` (e.g., `NASDAQ:AAPL`).
-   **Query Parameters**:
    -   `language` (string, optional): The language for localized content.
-   **Success Response (200)**: Returns a `SuccessResponse` with `AssetDetailData` containing the asset's profile.

### `GET /asset/{ticker}/price`

-   **Description**: Fetches the latest real-time price for a specific asset.
-   **Path Parameter**:
    -   `ticker` (string, required): The asset ticker.
-   **Query Parameters**:
    -   `language` (string, optional): The language for formatting.
-   **Success Response (200)**: Returns a `SuccessResponse` with `AssetPriceData` containing the latest price information.

### `GET /asset/{ticker}/price/historical`

-   **Description**: Retrieves historical OHLCV (Open, High, Low, Close, Volume) data for an asset.
-   **Path Parameter**:
    -   `ticker` (string, required): The asset ticker.
-   **Query Parameters**:
    -   `interval` (string, required): The data interval (e.g., `1d`, `1h`, `5m`).
    -   `start_date` (string, required): The start date in `YYYY-MM-DD` format.
    -   `end_date` (string, required): The end date in `YYYY-MM-DD` format.
    -   `language` (string, optional): The language for formatting.
-   **Success Response (200)**: Returns a `SuccessResponse` with `AssetHistoricalPricesData`.

### `GET /`

-   **Description**: Retrieves all watchlists associated with the default user.
-   **Success Response (200)**: Returns a `SuccessResponse` containing a list of `WatchlistData` objects.

### `POST /`

-   **Description**: Creates a new watchlist.
-   **Request Body**: `CreateWatchlistRequest` schema.
-   **Success Response (200)**: Returns a `SuccessResponse` with the newly created `WatchlistData`.

### `GET /{watchlist_name}`

-   **Description**: Retrieves a specific watchlist by its name.
-   **Path Parameter**:
    -   `watchlist_name` (string, required): The name of the watchlist.
-   **Query Parameters**:
    -   `include_prices` (boolean, optional, default: true): Whether to include real-time price data for the assets in the watchlist.
-   **Success Response (200)**: Returns a `SuccessResponse` with the requested `WatchlistData`.

### `DELETE /{watchlist_name}`

-   **Description**: Deletes an entire watchlist.
-   **Path Parameter**:
    -   `watchlist_name` (string, required): The name of the watchlist to delete.
-   **Success Response (200)**: Returns a success message.

### `POST /asset`

-   **Description**: Adds a new asset to a specified watchlist.
-   **Request Body**: `AddAssetRequest` schema, which includes the `ticker` and optional `watchlist_name`.
-   **Success Response (200)**: Returns a `SuccessResponse` with the created `WatchlistItemData`.

### `DELETE /asset/{ticker}`

-   **Description**: Removes an asset from a watchlist.
-   **Path Parameter**:
    -   `ticker` (string, required): The ticker of the asset to remove.
-   **Query Parameters**:
    -   `watchlist_name` (string, optional): The name of the watchlist. If not provided, the default watchlist is used.
-   **Success Response (200)**: Returns a success message.

### `PUT /asset/{ticker}/notes`

-   **Description**: Updates the user-provided notes for an asset within a watchlist.
-   **Path Parameter**:
    -   `ticker` (string, required): The asset ticker.
-   **Query Parameters**:
    -   `watchlist_name` (string, optional): The name of the watchlist.
-   **Request Body**: `UpdateAssetNotesRequest` schema containing the new `notes` text.
-   **Success Response (200)**: Returns a `SuccessResponse` with the updated `WatchlistItemData`.

---
## Agent API (`/agent`)

This API manages the lifecycle and interaction with various autonomous agents within the ValueCell platform.

### `GET /`

-   **Description**: Retrieves a list of all available agents.
-   **Success Response (200)**: Returns a list of agent information objects.

### `GET /{agent_id}`

-   **Description**: Fetches detailed information about a specific agent by its ID.
-   **Path Parameter**:
    -   `agent_id` (string, required): The unique identifier of the agent.
-   **Success Response (200)**: Returns the detailed information for the requested agent.

### `GET /by-name/{agent_name}`

-   **Description**: Retrieves agent details by its unique name.
-   **Path Parameter**:
    -   `agent_name` (string, required): The name of the agent.
-   **Success Response (200)**: Returns the agent's information.

### `POST /{agent_name}/enable`

-   **Description**: Enables or disables a specific agent.
-   **Path Parameter**:
    -   `agent_name` (string, required): The name of the agent.
-   **Request Body**: A simple JSON object, e.g., `{"enable": true}`.
-   **Success Response (200)**: Returns a status message indicating success.

---
## Conversation API (`/conversation`)

This API is responsible for managing chat conversations and their associated data, such as message history and scheduled tasks.

### `GET /`

-   **Description**: Retrieves a list of all conversations.
-   **Success Response (200)**: Returns a list of conversation metadata objects.

### `GET /{conversation_id}/history`

-   **Description**: Fetches the full message history for a specific conversation.
-   **Path Parameter**:
    -   `conversation_id` (string, required): The unique identifier for the conversation.
-   **Success Response (200)**: Returns a list of message objects.

### `DELETE /{conversation_id}`

-   **Description**: Deletes a conversation and all its associated messages.
-   **Path Parameter**:
    -   `conversation_id` (string, required): The ID of the conversation to delete.
-   **Success Response (200)**: Returns a confirmation message.

### `GET /scheduled-task-results`

-   **Description**: Retrieves the results of scheduled tasks from all conversations.
-   **Success Response (200)**: Returns a list of task result objects.

### `GET /{conversation_id}/scheduled-task-results`

-   **Description**: Fetches the results of scheduled tasks for a specific conversation.
-   **Path Parameter**:
    -   `conversation_id` (string, required): The ID of the conversation.
-   **Success Response (200)**: Returns a list of task results for the given conversation.

---
## Model Provider API (`/models`)

This API manages the configuration of Large Language Model (LLM) providers used by the agents.

### `GET /providers`

-   **Description**: Retrieves a list of all configured model providers (e.g., OpenAI, Azure, Google).
-   **Success Response (200)**: Returns a list of provider configuration objects.

### `GET /providers/{provider}`

-   **Description**: Fetches the detailed configuration for a specific provider.
-   **Path Parameter**:
    -   `provider` (string, required): The name of the provider (e.g., `openai`).
-   **Success Response (200)**: Returns the provider's configuration details.

### `PUT /providers/{provider}/config`

-   **Description**: Updates the configuration for a specific model provider, including the API key and base URL.
-   **Path Parameter**:
    -   `provider` (string, required): The name of the provider.
-   **Request Body**: A JSON object with the fields to update (e.g., `{"api_key": "..."}`).
-   **Success Response (200)**: Returns the updated provider configuration.

### `POST /providers/{provider}/models`

-   **Description**: Adds a new model to a provider's list of available models.
-   **Path Parameter**:
    -   `provider` (string, required): The name of the provider.
-   **Request Body**: A JSON object describing the model to be added.
-   **Success Response (200)**: Returns the updated provider configuration.

### `DELETE /providers/{provider}/models`

-   **Description**: Removes a model from a provider's list.
-   **Path Parameter**:
    -   `provider` (string, required): The name of the provider.
-   **Request Body**: A JSON object specifying the model to be removed.
-   **Success Response (200)**: Returns the updated provider configuration.

### `PUT /providers/default`

-   **Description**: Sets the default model provider for the entire application.
-   **Request Body**: A JSON object specifying the default provider, e.g., `{"provider": "openai"}`.
-   **Success Response (200)**: Returns a success message.

### `PUT /providers/{provider}/default-model`

-   **Description**: Sets the default model for a specific provider.
-   **Path Parameter**:
    -   `provider` (string, required): The name of the provider.
-   **Request Body**: A JSON object with the default model name, e.g., `{"model": "gpt-4"}`.
-   **Success Response (200)**: Returns a success message.

### `POST /check`

-   **Description**: Tests the connection to a model provider with the given credentials.
-   **Request Body**: A JSON object containing the provider name and credentials to test.
-   **Success Response (200)**: Returns a status indicating whether the connection was successful.

---
## Strategy API (`/strategy`)

This API is used to manage and monitor automated trading strategies.

### `GET /`

-   **Description**: Retrieves a list of all trading strategies.
-   **Success Response (200)**: Returns a list of strategy objects.

### `GET /performance`

-   **Description**: Fetches performance data for a specific strategy.
-   **Query Parameters**:
    -   `strategy_id` (string, required): The ID of the strategy.
-   **Success Response (200)**: Returns performance metrics for the strategy.

### `GET /holding`

-   **Description**: Retrieves the current holdings or positions for a strategy.
-   **Query Parameters**:
    -   `strategy_id` (string, required): The ID of the strategy.
-   **Success Response (200)**: Returns a list of current positions.

### `GET /portfolio_summary`

-   **Description**: Provides a summary of the trading portfolio associated with a strategy.
-   **Query Parameters**:
    -   `strategy_id` (string, required): The ID of the strategy.
-   **Success Response (200)**: Returns a portfolio summary object.

### `GET /detail`

-   **Description**: Fetches the detailed configuration and status of a single strategy.
-   **Query Parameters**:
    -   `strategy_id` (string, required): The ID of the strategy.
-   **Success Response (200)**: Returns the detailed strategy object.

### `GET /holding_price_curve`

-   **Description**: Retrieves the historical price curve for the strategy's holdings.
-   **Query Parameters**:
    -   `strategy_id` (string, required): The ID of the strategy.
-   **Success Response (200)**: Returns data points for the price curve.

### `POST /stop`

-   **Description**: Stops a running trading strategy.
-   **Request Body**: A JSON object with the `strategy_id` to stop.
-   **Success Response (200)**: Returns a confirmation message.

---
